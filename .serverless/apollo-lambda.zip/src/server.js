exports.API_URL =
  process.env.NODE_ENV === 'dev'
    ? 'http://api-dev.ifbyphone.com/v1/'
    : process.env.NODE_ENV === 'test'
    ? 'http://api-test.ifbyphone.com/v1/'
    : process.env.NODE_ENV === 'prod'
    ? 'https://api.ifbyphone.com/v1/'
    : 'http://api.ifbyphone.local/v1';
