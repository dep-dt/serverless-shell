const { RESTDataSource } = require('apollo-datasource-rest');
const { API_URL } = require('./server.js');

class OrganicAPI extends RESTDataSource {
  constructor() {
    super();
    this.baseURL = API_URL;
  }

  willSendRequest(request) {
    request.headers.set('Cookie', 'IFBYPHONE=f89932e8cc6bca3cf7a3e5b0e04e6f80');
  }

  async getRegisteredNumbers() {
    const data = await this.get('rpc', {
      action: 'getRegisteredNumbers',
      includeIbp: 1,
      baseUrl: API_URL,
    });
    return JSON.parse(data)[0].number;
  }
}

exports.OrganicAPI = OrganicAPI;
